{{/*
Expand the name of the chart.
*/}}
{{- define "a2a-slack-bot.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "a2a-slack-bot.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart name and version label.
*/}}
{{- define "a2a-slack-bot.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "a2a-slack-bot.labels" -}}
helm.sh/chart: {{ include "a2a-slack-bot.chart" . }}
{{ include "a2a-slack-bot.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "a2a-slack-bot.selectorLabels" -}}
app.kubernetes.io/name: {{ include "a2a-slack-bot.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Name of the service account to use.
*/}}
{{- define "a2a-slack-bot.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "a2a-slack-bot.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Name of the pre-existing Secret holding the Slack tokens. Required — the chart
never creates this Secret, it only references it.
*/}}
{{- define "a2a-slack-bot.secretName" -}}
{{- required "slack.secretName is required: create a Secret with the Slack tokens and reference it via slack.secretName. See the chart README." .Values.slack.secretName }}
{{- end }}
