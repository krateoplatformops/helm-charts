# a2a-slack-bot Helm chart

Deploys the Slack Socket Mode bot that bridges Slack to a agent over A2A.

## Slack credentials (required)

This chart **does not create or manage the Slack tokens**. You must create a
Kubernetes Secret yourself and reference it via `slack.secretName`. If
`slack.secretName` is empty, `helm install`/`helm upgrade` fails with a clear
error before anything is rendered.

The Secret must contain two string keys:

| Key (default)     | Value                                  | Override with        |
| ----------------- | -------------------------------------- | -------------------- |
| `SLACK_BOT_TOKEN` | Slack bot token (`xoxb-…`)             | `slack.botTokenKey`  |
| `SLACK_APP_TOKEN` | Slack app-level token (`xapp-…`)       | `slack.appTokenKey`  |

The Secret must live in the same namespace as the release.

### Create the Secret

With `kubectl` (handles base64 for you — pass the raw strings):

```bash
kubectl create secret generic slack-bot-tokens \
  --namespace <your-namespace> \
  --from-literal=SLACK_BOT_TOKEN='xoxb-your-bot-token' \
  --from-literal=SLACK_APP_TOKEN='xapp-your-app-token'
```

Or as a manifest using `stringData` (no manual base64):

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: slack-bot-tokens
  namespace: <your-namespace>
type: Opaque
stringData:
  SLACK_BOT_TOKEN: "xoxb-your-bot-token"
  SLACK_APP_TOKEN: "xapp-your-app-token"
```

### Reference it in the release

```bash
helm upgrade --install a2a-slack-bot ./chart \
  --namespace <your-namespace> \
  --set slack.secretName=slack-bot-tokens
```

Or in a values file:

```yaml
slack:
  secretName: slack-bot-tokens
```

### Using custom key names

If your Secret stores the tokens under different keys, set `slack.botTokenKey`
and `slack.appTokenKey` to match:

```yaml
slack:
  secretName: my-secret
  botTokenKey: bot-token
  appTokenKey: app-token
```

## Key values

| Value                | Description                                              | Default                          |
| -------------------- | -------------------------------------------------------- | -------------------------------- |
| `slack.secretName`   | **Required.** Name of the pre-existing Secret to use.    | `""`                             |
| `slack.botTokenKey`  | Key in the Secret holding the bot token.                 | `SLACK_BOT_TOKEN`                |
| `slack.appTokenKey`  | Key in the Secret holding the app-level token.           | `SLACK_APP_TOKEN`                |
| `agent.a2aUrl`       | A2A endpoint of the agent the bot talks to.              | see `values.yaml`                |
| `image.repository`   | Bot container image.                                     | `ghcr.io/kagent-dev/a2a-slack-bot` |
| `image.tag`          | Image tag (defaults to chart `appVersion` when empty).   | `""`                             |
